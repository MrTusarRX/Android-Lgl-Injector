package uk.lgl.modmenu;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;

public class MainActivity extends Activity {
	static native void setDarkStart(Context ctx);

    public static void Start(Context ctx) {
        setDarkStart(ctx);
    }
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		
		System.loadLibrary("Alexandre");
		
		setDarkStart(this);
    }
}
